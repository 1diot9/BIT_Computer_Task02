from .rshifter import *

__doc__ = rshifter.__doc__
if hasattr(rshifter, "__all__"):
    __all__ = rshifter.__all__